# Abdulaziz Basta Manager — Android APK project

Arabic, offline-first stock/sales/production/expenses dashboard packaged in an Android WebView.

## Build APK from a phone using GitHub Actions
1. On your phone, open GitHub in Chrome and create a **new public or private repository**.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository, preserving folder paths.
3. Open the repository's **Actions** tab. If asked, enable Actions.
4. Choose **Build Basta Manager APK** → **Run workflow**.
5. Wait for the workflow to turn green. Open that run, scroll to **Artifacts**, and download `Abdulaziz-Basta-Manager-APK`.
6. Extract the downloaded artifact ZIP if needed, then tap `app-debug.apk` to install it.

If the repository is private, keep it private. Do not upload customer financial data into GitHub; this repository contains source code only.

## Notes
- This workflow builds a **debug APK** for testing/sideloading, not a Play Store release.
- The app's data is stored locally in WebView storage on the device. Export backups from Settings inside the app regularly.
- Test with sample entries first. The initial app is a prototype and does not yet have separate secure owner/staff accounts.
- This is a minimal Android wrapper project; the included HTML is the offline interface.
